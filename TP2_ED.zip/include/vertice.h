#ifndef VERTICE_H
#define VERTICE_H

struct Vertice{
    int indice;
    float x, y;
};

#endif // VERTICE_H